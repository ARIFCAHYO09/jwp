<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><b>Melihat Data Laporan Kerusakan</b></div>

                <nav aria-label="Page navigation example">
                  <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                  </ul>
                </nav>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th>tgl</th>
                          <th scope="col">Ruang</th>
                          <th scope="col">Jenis Kerusakan</th>
                          <th scope="col">Permasalahan</th>
                          <th scope="col">Pelapor</th>
                          <th scope="col">Gambar</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td scope="row"><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($p->created_at); ?></td>
                          <td><?php echo e($p->ruang); ?></td>
                          <td><?php echo e($p->jenis_kerusakan); ?></td>
                          <td><?php echo e($p->keterangan); ?></td>
                          <td><?php echo e($p->email); ?></td>
                          <td>
                            <img src="<?php echo e($p->gambar); ?>" width="100px" height="100px">
                            <br>
                            <center>
                            <a href="<?php echo e($p->gambar); ?>" download="">Downloads</a>
                            </center>
                          </td>
                          <td><a href="/pengaduan/edit/<?php echo e($p->id); ?>">Edit<a>&nbsp;<a href="/pengaduan/hapus/<?php echo e($p->id); ?>" style="color: red;">Hapus<a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/home.blade.php ENDPATH**/ ?>